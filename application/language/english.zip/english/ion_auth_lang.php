<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Ion Auth Lang - English
*
* Author: Ben Edmunds
* 		  ben.edmunds@gmail.com
*         @benedmunds
*
* Location: http://github.com/benedmunds/ion_auth/
*
* Created:  03.14.2010
*
* Description:  English language file for Ion Auth messages and errors
*
*/


$lang['label_teacher_recommendation_about_the_students'] = 'Teacher Recommendation about the Students';
$lang['label_social_vulnerability'] = 'Social Vulnerability';
$lang['label_detail_of_the_vulnerability'] = 'Detail of the vulnerability';
$lang['label_probability_of_early_marriage'] = 'Probability Of Early Marriage';
$lang['label_comments'] = 'Comments';

$lang['label_guardian_family_information'] = 'Guardian & Family Information';
$lang['label_guardians_name'] = 'Guardians Name';
$lang['label_guardians_nid_no'] = 'Guardian NID No';
$lang['label_relation_with_guardian'] = 'Relation With Guardian';
$lang['label_parents_guardian_email'] = 'Parents/Guardian Email';
$lang['label_parents_guardian_mobile_no'] = 'Parents/Guardian Mobile No';
$lang['label_parents_guardian_educational_qualification'] = 'Parents/Guardian Educational Qualification';
$lang['label_parents_guardian_occupation'] = 'Parents/Guardians Occupation';
$lang['label_parents_guardian_monthly_income'] = 'Parents/Guardians Monthly Income';
$lang['label_number_of_family_members'] = 'Number Of Family Members';
$lang['label_getting_any_financial_support'] = 'Getting Any Financial Support';
$lang['label_economical_status_of_student_family'] = 'Economical Status of Students Family';

$lang['label_student_name'] = 'Name';
$lang['label_basic_information'] = 'Basic Information';
$lang['label_institute_type'] = 'Institute Type';
$lang['label_number_of_students'] = 'Number Of Student';
$lang['label_number_of_teachers'] = 'Number Of Teacher';
$lang['label_website'] = 'Website';
$lang['label_social_web_link'] = 'Social Web Link';
$lang['label_contact_information'] = 'Contact Information';
$lang['label_category_of_institution'] = 'Category of Institution';
$lang['label_designation_of_institute_head'] = 'Designation Of Institute Head';
$lang['label_name_of_institute_head'] = 'Name Of Institute Head';
$lang['label_email'] = 'Email';
$lang['label_mobile'] = 'Mobile';
$lang['label_phone'] = 'Phone';
$lang['label_students_name'] = 'Student Name ';
$lang['label_teachers_name'] = 'Teacher Name';
$lang['label_professional_information'] = 'Professional Information';
$lang['label_designation'] = 'Designation';
$lang['label_mpo_no'] = 'MPO No.';
$lang['label_personal_information'] = 'Personal Information';

$lang['label_nid'] = 'NID';

//Setting
$lang['label_division_name'] = 'Division Name';
$lang['label_district_name'] = 'District Name';
$lang['label_upazila_name'] = 'Upazila Name';
$lang['label_village_name'] = 'Village Name';
$lang['label_union_name'] = 'Union Name';
$lang['label_thana_name'] = 'Thana Name';
$lang['label_roll'] = 'Roll';
$lang['label_profession'] = 'Profession';
$lang['label_organization'] = 'Organization';
$lang['label_holiday_name'] = 'Holiday Name';

$lang['label_start_date'] = 'Start Date';
$lang['label_end_date'] = 'End Date';
$lang['label_no_of_days'] = 'No of Days';
$lang['label_disability_name'] ='Disability Name';

$lang['label_education_level_name'] = 'Education Level Name';
$lang['label_institute_type_name'] = 'Institute Type Name';
$lang['label_stipend_level_name'] = 'Stipend Level Name';
$lang['label_income_range_name'] = 'Income Range Name';
$lang['label_risk_name'] = 'Risk Name';
$lang['label_economic_status_name'] = 'Economic Status Name ';
$lang['label_financial_support_name'] = 'Financial Support Name';

//Early Marrige
$lang['label_early_marrige_risk'] ='Early Marrige Risk';
$lang['label_sssign_a_stakeholder_for_action'] = 'Assign a Stakeholder for Action';
$lang['label_recommended_action_from_social_saftey_net'] = 'Recommended Action from Social Saftey Net';
$lang['label_absent_flag'] = 'Absent Flag(NO)';
$lang['label_actions_taken_by_stakeholder'] = 'Actions Taken By Stakeholder';
$lang['label_stakeholder_name_who_took_actions'] = 'Stakeholder Name Who Took Actions';
$lang['label_continuing_study'] = 'Continuing Study';
$lang['label_pass_class_ten'] = 'Pass Class Ten';
$lang['label_early_marrige_risk_name'] = 'Early Marrige Risk Name';
$lang['label_btn_assign'] = 'Assign';

//AddressBook
$lang['label_stakeholder_role'] = 'Stakeholder Role';
$lang['label_organization_address'] = 'Organization Address';
$lang['label_stakeholder_name'] = 'Stakeholder Name';
$lang['label_contact_info_as_reference'] = 'Contact info as reference';
$lang['label_altr_email'] = 'Alternative Email';
$lang['label_altr_mobile'] = 'Alternative Mobile';


//Dropout
$lang['label_total_approved_leave'] = 'Total Approved Leave';
$lang['label_flag_who_are_under_monitoring'] = 'Flag(Who are under monitoring)';
$lang['label_dropout_name'] = 'Dropout Name ';
$lang['label_dropout_type'] = 'Dropout Type';
$lang['label_assign_stakeholder_for_consideration_to_take_initiative'] = 'Assign Stakeholder for Consideration to take initiative';
$lang['label_assign_stakeholder_for_new_recommendation'] = 'Assign Stakeholder for new recommendation';
$lang['label_give_flag_as_under_second_level_monitoring'] = 'Give Flag as Under Second Level Monitoring';
$lang['label_assign_specific_social_saftey_net_service'] = 'Assign Specific Social Safety Net Service';
$lang['label_feedback_to_assignee_authority'] = 'Feedback To Assignee Authority';
$lang['label_give_flag_as_under_first_level_monitoring'] = 'Give Flag As Under First Level Monitoring';


//SSNM
$lang['label_service_name'] = 'Service Name';
$lang['label_service_type'] = 'Service Type';
$lang['label_application_id'] = 'Application ID';
$lang['label_problem_description'] = 'Problem Description';
$lang['label_expected_solution'] = 'Expected Solution';
$lang['label_teacher_comments'] = 'Teacher Comments';
$lang['label_status'] = 'Status';
$lang['label_action'] = 'Action';
$lang['label_assign_for_specific_action'] = 'Assign for Specific Action';
$lang['label_problem_details'] = 'Problem Details';
$lang['label_action_details'] = 'Action Details';
$lang['label_execution_done'] = 'Execution Done';
$lang['label_assigned_authority'] = 'Assigned Authority';
$lang['label_feedback_details'] = 'Feedback Details';

//Notification
$lang['label_category_name'] = 'Category Name';
$lang['label_content_name'] = 'Content Name';
$lang['label_title'] = 'Title';
$lang['label_select_role'] = 'Select Role';

//Absent
$lang['label_absent_name'] = 'Absent Name';
$lang['label_date'] = 'Date';

//Promotion
$lang['label_previous_year'] = 'Previous Year';
$lang['label_current_year'] = 'Current Year';
$lang['label_sl_no'] = 'SL No';
$lang['label_promotion_pending_students'] = 'Promotion Pending Students List';

//Administrator
$lang['label_first_name'] = 'First Name';
$lang['label_last_name'] = 'Last Name';
$lang['label_password'] = 'Password';
$lang['label_confirm_password'] = 'Confirm Password';
$lang['label_user_group'] = 'User Group';
$lang['label_user_name'] = 'User Name';
$lang['label_members_of_group'] = 'Member of Groups';
$lang['label_name'] = 'Name';
$lang['label_address'] = 'Address';
$lang['label_user_company_information'] = 'User Company Information';
$lang['label_contact'] = 'Contact';
$lang['label_web'] = 'Web';
$lang['label_description'] = 'Description';
$lang['label_user_role_information'] = 'User Role Information';
$lang['label_total_income'] = 'Total Income';
$lang['label_user_wallet_information'] = 'User Wallet Information';
$lang['label_total_expense'] = 'Total Expense';
$lang['label_total_due'] = 'Total Due';


//Button
$lang['label_btn_save'] = 'Save';
$lang['label_btn_submit'] = 'Submit';
$lang['label_btn_reset'] = 'Reset';
$lang['label_btn_serach'] = 'Search';
$lang['label_btn_edit'] = 'Edit';
$lang['label_btn_delete'] = 'Delete';
$lang['label_btn_view'] = 'View';
$lang['label_btn_update'] = 'Update';
$lang['label_btn_edit_profile'] = 'Edit Profile';
$lang['label_user_list'] = 'User List';
$lang['label_create_user'] = 'Create User';
$lang['label_user_edit'] = 'User Edit';
$lang['label_create_group'] = 'Create Group';
$lang['label_group_name'] = 'Group Name';
$lang['label_description_name'] = 'Description Name';
$lang['label_yes_no'] = 'Yes/No';
$lang['label_feedback'] = 'Feedback';
$lang['label_send_message'] = 'Send Message';

//Heading
$lang['label_organization_form  '] = 'Organization Form';
$lang['label_organization_list'] = 'Organization List';
$lang['label_organization_edit'] = 'Organization Edit';
$lang['label_school_list'] = 'School List';
$lang['label_school_profile_form'] = 'Institute Profile Form';
$lang['label_school_profile_form_edit'] = 'Institute Profile Form Edit';
$lang['label_teacher_list'] = 'Teacher List';
$lang['label_teacher_registration_form'] = 'Teacher Registration Form';
$lang['label_teacher_registration_form_edit'] = 'Teacher Registration Form Edit';
$lang['label_student_list'] = 'Student Registration Form';
$lang['label_student_registration_form'] = 'Student Registration Form';
$lang['label_student_registration_form_edit'] = 'Student Registration Form Edit';
$lang['label_student_promotion_form'] = 'Student Promotion Form';
$lang['label_student_promotion_history'] = 'Promotion History';
$lang['label_student_promoted_history'] = 'Promoted Student';
$lang['label_absent_student_list'] = 'Absent Students List';
$lang['label_absent_student_form'] = 'Absent student Form';
$lang['label_risk_list'] = 'Risk List';
$lang['label_stakeholder_registration_form'] = 'Stakeholder Registration Form';
$lang['label_stakeholder_registration_list'] = 'Stakeholder List';
$lang['label_stakeholder_registration_form_edit'] = 'Stakeholder Registration Form Edit';
$lang['label_permanent_dropout_student'] = 'Parmanent Dropout Students';
$lang['label_temporary_dropout_student'] = 'Temporary Dropout Students';
$lang['label_remporary_dropout_stakeholder_assign_form'] = 'Temporary Dropout: Stakeholder Assign Form';
$lang['label_temporary_dropout_stakeholder_action_execution_form'] = 'Temporary Dropout: Stakeholder Action Execution Form';
$lang['label_second_level_follow_up_form'] = 'Temporary Dropout: Second Level Follow Up Form';
$lang['label_student_who_are_under_social_safety_net_service'] = 'Student List Who Are Under Social Safety Net Services';
$lang['label_student_who_were_under_social_safety_net_service'] = 'Temporary Dropout: Student List Who Were Under Social Safety Net Services';
$lang['label_notification_category'] = 'Notification categorys';
$lang['label_notification_category_entry_form'] = 'Notification Category Entry Form';
$lang['label_notification_category_edit_form'] = 'Notification Category edit Form';
$lang['label_notification_content'] = 'Notification Contents';
$lang['label_notification_content_entry_form'] = 'Notification Content Entry Form';
$lang['label_notification_content_edit_form'] = 'Notification Content Edit Form';
$lang['label_send_sms'] = 'Sms Send';
$lang['label_sms_list'] = 'Sms List';
$lang['label_send_vms'] = 'Voice Message';
$lang['label_class_list'] = 'Class List';
$lang['label_class_entry_form'] = 'Class Entry Form';
$lang['label_class_edit_form'] = 'Class Edit Form';
$lang['label_section_list'] = 'Section List';
$lang['label_section_entry_form'] = 'Section Entry Form';
$lang['label_section_edit_form'] = 'Section Edit Form';
$lang['label_group_list'] = 'Group List';
$lang['label_group_entry_form'] = 'Group Entry Form';
$lang['label_group_edit_form'] = 'Group Edit Form';
$lang['label_education_level_list'] = 'Education Level List';
$lang['label_education_level_entry_form'] = 'Education Level Entry Form';
$lang['label_education_level_edit_form'] = 'Education Level Edit Form';
$lang['label_institute_list'] = 'Institute List';
$lang['label_institute_level_entry_form'] = 'Institute Entry Form';
$lang['label_institute_level_edit_form'] = 'Institute Edit Form';
$lang['label_school_list'] = 'School List';
$lang['label_school_entry_form'] = 'School Entry Form';
$lang['label_school_edit_form'] = 'School Edit Form';

$lang['label_designation_list'] = 'Designation List';
$lang['label_designation_entry_form'] = 'Designation Entry Form';
$lang['label_designation_edit_form'] = 'Designation Edit Form';

$lang['label_profession_list'] = 'Profession List';
$lang['label_profession_entry_form'] = 'Profession Entry Form';
$lang['label_profession_edit_form'] = 'Profession Edit Form';

$lang['label_role_list'] = 'Role List';
$lang['label_role_entry_form'] = 'Role Entry Form';
$lang['label_role_edit_form'] = 'Role Edit Form';

$lang['label_holiday_list'] = 'Holiday List';
$lang['label_holiday_entry_form'] = 'Holiday Entry Form';
$lang['label_holiday_edit_form'] = 'Holiday Edit Form';

$lang['label_disability_list'] = 'Disability List';
$lang['label_disability_entry_form'] = 'Disability Entry Form';
$lang['label_disability_edit_form'] = 'Disability Edit Form';

$lang['label_financial_support_list'] = 'Financial Support List';
$lang['label_financial_support_entry_form'] = 'Financial Support Entry Form';
$lang['label_financial_support_edit_form'] = 'Financial Support Edit Form';

$lang['label_economic_status_list'] = 'Economic Status list';
$lang['label_economic_status_entry_form'] = 'Economic Status Entry Form';
$lang['label_economic_status_edit_form'] = 'Economic Status Edit Form';

$lang['label_risk_of_early_marriage_list'] = 'Risk of early marriage list';
$lang['label_risk_of_early_marriage_entry_form'] = 'Risk of early marriage Entry Form';
$lang['label_risk_of_early_marriage_edit_form'] = 'Risk of early marriage Edit Form';

$lang['label_income_range_list'] = 'Income Range List';
$lang['label_income_range_entry_form'] = 'Income Range Entry Form';
$lang['label_income_range_edit_form'] = 'Income Range Edit Form';

$lang['label_religion_list'] = 'Religion List';
$lang['label_religion_entry_form'] = 'Religion Entry Form';
$lang['label_religion_edit_form'] = 'Religion Edit Form';

$lang['label_stipend_list'] = 'Stipend List';
$lang['label_stipend_entry_form'] = 'Stipend Entry Form';
$lang['label_stipend_edit_form'] = 'Stipend Edit Form';

$lang['label_add_new'] = 'Add New';

$lang['label_user_account'] = 'User Account';
$lang['label_profile'] = 'Profile';
$lang['label_change_password'] = 'Change Password';
$lang['label_logout'] = 'Logout ';

$lang['label_send_email'] = 'Send Email';
$lang['label_select_role'] = 'Select Role';

$lang['label_vms_name'] = 'Name';

$lang['label_total_data'] = 'Total Data';

$lang['label_data_submit_fail'] = 'Data Submission Failed';
$lang['label_data_submit_success'] = 'Data Submission Success';

$lang['label_stakehoder_assign_list'] = 'Stakeholder Assign List';
$lang['label_stakehoder_action_execution_list'] = 'Stakeholder Assign List';
$lang['label_result_after_getting_support'] = 'Result After Getting Support';
$lang['label_recovery_list'] = 'Recovery List';