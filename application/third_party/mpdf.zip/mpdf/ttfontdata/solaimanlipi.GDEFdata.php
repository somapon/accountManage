<?php
$GSUB_offset = 244604;
$GPOS_offset = 244556;
$GSUB_length = 4928;
$GlyphClassBases = ' 0FFFF';
$GlyphClassMarks = '';
$GlyphClassLigatures = '';
$GlyphClassComponents = '';
$MarkGlyphSets = array (
);
$MarkAttachmentType = array (
);
?>