<?php
$name='SolaimanLipi';
$type='TTF';
$desc=array (
  'CapHeight' => 863.0,
  'XHeight' => 0.0,
  'FontBBox' => '[-553 -434 1116 863]',
  'Flags' => 4,
  'Ascent' => 863.0,
  'Descent' => -267.0,
  'Leading' => 0.0,
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 863.0,
);
$unitsPerEm=2048;
$up=-65;
$ut=10;
$strp=259;
$strs=50;
$ttffile='H:/xampp/htdocs/ed/application/third_party/mpdf/ttfonts/SolaimanLipi.ttf';
$TTCfontID='0';
$originalsize=249532;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='solaimanlipi';
$panose=' 0 0 2 0 5 0 2 0 0 2 0 4';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 800, 200, 0
// usWinAscent/usWinDescent = 863, -267
// hhea Ascent/Descent/LineGap = 863, -293, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'beng' => 'DFLT ',
  'latn' => 'DFLT ',
);
$GSUBFeatures=array (
  'beng' => 
  array (
    'DFLT' => 
    array (
      'init' => 
      array (
        0 => 1,
      ),
      'akhn' => 
      array (
        0 => 2,
      ),
      'rphf' => 
      array (
        0 => 3,
      ),
      'blwf' => 
      array (
        0 => 4,
      ),
      'half' => 
      array (
        0 => 5,
      ),
      'pstf' => 
      array (
        0 => 6,
      ),
      'vatu' => 
      array (
        0 => 7,
      ),
      'pres' => 
      array (
        0 => 8,
      ),
      'blws' => 
      array (
        0 => 9,
        1 => 10,
      ),
      'psts' => 
      array (
        0 => 11,
      ),
      'haln' => 
      array (
        0 => 12,
      ),
      'locl' => 
      array (
        0 => 13,
      ),
      'frac' => 
      array (
        0 => 14,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'aalt' => 
      array (
        0 => 0,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245000,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245030,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245048,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245074,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245112,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245176,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245648,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 245672,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246060,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 247558,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 248042,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 248852,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 248964,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 249436,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 249454,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'beng' => 'DFLT ',
  'latn' => 'DFLT ',
);
?>